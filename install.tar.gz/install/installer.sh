#!/bin/bash

mkdir /home/project2
chmod 777 /home/project2
cp project2/combo.sh /home/project2/combo.sh
chmod +x /home/project2/combo.sh

mkdir /var/www/html/sam_project2
chmod 755 /var/www/html/sam_project2
cp sam_project2/index.php /var/www/html/sam_project2/index.php
##mkdir /var/www/html/sam_project2/results
##chmod 777 /var/www/html/sam_project2/results
